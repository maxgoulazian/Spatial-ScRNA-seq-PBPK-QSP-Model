#!/bin/bash
# AF3 fold shard runner — runs all JSONs in a shard tarball, CONC-concurrent on one GPU.
# args: $1 = shard tarball name (staged flat in /work)  $2 = concurrency (default 10)
set -e
SHARD=$1; CONC=${2:-10}
echo "=== AF3 shard $SHARD | concurrency $CONC ==="
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
mkdir -p /work/jsons /work/foldout /work/out
tar xzf /work/$SHARD -C /work/jsons
NJ=$(ls /work/jsons/*_data.json | wc -l)
echo "unpacked $NJ fold JSONs"

# process in waves of $CONC
files=(/work/jsons/*_data.json)
total=${#files[@]}
i=0; done=0; T0=$(date +%s)
while [ $i -lt $total ]; do
  pids=""
  for j in $(seq 1 $CONC); do
    [ $i -ge $total ] && break
    f="${files[$i]}"; base=$(basename "$f" _data.json)
    XLA_PYTHON_CLIENT_PREALLOCATE=false python3 /app/alphafold/run_alphafold.py \
      --json_path="$f" --model_dir=/root/models --output_dir=/work/foldout \
      --norun_data_pipeline > /work/foldout/${base}.log 2>&1 &
    pids="$pids $!"; i=$((i+1))
  done
  wait $pids
  done=$i
  echo "[$(($(date +%s)-T0))s] completed $done/$total"
done
echo "=== all folds done in $(($(date +%s)-T0))s ==="

# collect ONLY the small summary JSONs into ./out (NOT the big cif/pae — harvest-safe)
# we need: summary_confidences.json (iptm, ptm, chain_pair_*, ranking) + confidences.json (PAE matrix for ipSAE)
n_ok=0
for d in /work/foldout/*/; do
  [ -d "$d" ] || continue
  name=$(basename "$d")
  mkdir -p /work/out/$name
  # AF3 writes <name>_summary_confidences.json and <name>_confidences.json and ranking_scores.csv
  cp "$d"/*summary_confidences.json /work/out/$name/ 2>/dev/null && n_ok=$((n_ok+1)) || true
  cp "$d"/*_confidences.json /work/out/$name/ 2>/dev/null || true
  cp "$d"/ranking_scores.csv /work/out/$name/ 2>/dev/null || true
  # keep the top-ranked model cif for finalists' RMSD/shape-complementarity
  top=$(ls "$d"/*model.cif 2>/dev/null | head -1); [ -n "$top" ] && cp "$top" /work/out/$name/ 2>/dev/null || true
done
echo "=== harvested $n_ok summary sets into ./out ==="
ls /work/out | head -5; echo "... ($(ls /work/out | wc -l) fold dirs in out)"
