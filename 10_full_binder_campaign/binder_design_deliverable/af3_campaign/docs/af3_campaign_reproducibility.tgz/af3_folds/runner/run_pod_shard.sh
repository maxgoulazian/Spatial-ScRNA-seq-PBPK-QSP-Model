#!/bin/bash
# Args: $1=shard_tar $2=concurrency $3=seeds  — runs on the pod, banks each fold to /workspace/out
set -u
TAR=$1; CONC=${2:-10}; SEEDS=${3:-1}
cd /workspace
mkdir -p in out foldlog
tar xzf $TAR -C in/
export XLA_FLAGS="--xla_gpu_enable_command_buffer="
export XLA_PYTHON_CLIENT_PREALLOCATE=false
running=0
for j in in/*.json; do
  b=$(basename $j .json)
  [ -f out/$b/${b}_summary_confidences.json ] && continue   # skip done (resume-safe)
  ( /alphafold3_venv/bin/python /app/alphafold/run_alphafold.py --json_path=$j \
      --model_dir=/workspace/models --output_dir=/workspace/out \
      --norun_data_pipeline \
      > foldlog/$b.log 2>&1 ) &
  running=$((running+1))
  if [ $running -ge $CONC ]; then wait -n; running=$((running-1)); fi
done
wait
echo "SHARD_DONE $(ls out | wc -l) folds"
