#!/bin/bash
cd /dev/shm/af3
mkdir -p ten_in ten_out foldlog
while read f; do
  [ -z "$f" ] && continue
  python3 -c "
import json
d=json.load(open('screen_in/$f'))
d['modelSeeds']=[1,2,3,4,5,6,7,8,9,10]
json.dump(d,open('ten_in/$f','w'))
"
done < ten_add_list.txt
echo "added to ten_in: $(ls ten_in/*.json|wc -l) total"
NG=$(nvidia-smi -L | wc -l); PY=/alphafold3_venv/bin/python
export XLA_PYTHON_CLIENT_PREALLOCATE=false
i=0
while read f; do
  [ -z "$f" ] && continue
  j=ten_in/$f; b=$(basename $j .json); g=$((i % NG))
  CUDA_VISIBLE_DEVICES=$g JAX_COMPILATION_CACHE_DIR=/dev/shm/af3/tajx_$i $PY /app/alphafold/run_alphafold.py \
    --json_path=$j --model_dir=/dev/shm/af3/models --output_dir=/dev/shm/af3/ten_out \
    --norun_data_pipeline > foldlog/tenadd_$b.log 2>&1 &
  i=$((i+1))
  while [ $(jobs -rp | wc -l) -ge 12 ]; do wait -n; done
  [ $i -le 12 ] && sleep 3
done < ten_add_list.txt
wait
echo "TENADD_DONE launched=$i"
