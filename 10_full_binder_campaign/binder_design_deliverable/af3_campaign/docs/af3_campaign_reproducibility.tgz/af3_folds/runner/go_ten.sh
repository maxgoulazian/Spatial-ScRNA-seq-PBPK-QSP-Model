#!/bin/bash
pkill -f run_alphafold 2>/dev/null; sleep 3
setsid nohup bash /dev/shm/af3/tenseed.sh > /dev/shm/af3/ten_run.log 2>&1 < /dev/null &
echo "GO_TEN_STARTED pid $!"
