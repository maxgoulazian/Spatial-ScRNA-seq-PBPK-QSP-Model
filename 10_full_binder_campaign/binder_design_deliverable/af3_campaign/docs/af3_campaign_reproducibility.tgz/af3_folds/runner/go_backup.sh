#!/bin/bash
pkill -f backup.sh 2>/dev/null; sleep 1
setsid nohup bash /dev/shm/af3/backup.sh > /dev/shm/af3/backup.log 2>&1 < /dev/null &
echo "BACKUP_STARTED pid $!"
