#!/bin/bash
# Args: $1=indir  $2=total_parallel (e.g. 21 = 3/GPU x7)
set -u
INDIR=$1; P=${2:-21}
cd /dev/shm/af3
mkdir -p out foldlog jax_cache
NG=$(nvidia-smi -L | wc -l)
PY=/alphafold3_venv/bin/python
export XLA_PYTHON_CLIENT_PREALLOCATE=false PY NG
run_one(){
  local j=$1
  local b=$(basename $j .json)
  local lb=${b,,}
  [ -f /dev/shm/af3/out/$lb/${lb}_summary_confidences.json ] && return 0
  # GPU = hash of name mod NG (stable, spreads load)
  local g=$(( $(echo $b | cksum | cut -d' ' -f1) % NG ))
  CUDA_VISIBLE_DEVICES=$g $PY /app/alphafold/run_alphafold.py \
    --json_path=$j --model_dir=/dev/shm/af3/models --output_dir=/dev/shm/af3/out \
    --norun_data_pipeline --jax_compilation_cache_dir=/dev/shm/af3/jax \
    > /dev/shm/af3/foldlog/$b.log 2>&1
}
export -f run_one
# feed only NOT-yet-done jsons to xargs; -P keeps exactly P running at all times
ls $INDIR/*.json | xargs -P $P -I{} bash -c 'run_one "$@"' _ {}
echo "XARGS_DONE out=$(ls out | wc -l)"
