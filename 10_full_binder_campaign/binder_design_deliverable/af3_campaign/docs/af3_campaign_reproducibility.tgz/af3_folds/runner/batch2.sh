#!/bin/bash
INDIR=$1
P=${2:-14}
cd /dev/shm/af3
mkdir -p out foldlog
NG=$(nvidia-smi -L | wc -l)
PY=/alphafold3_venv/bin/python
export XLA_PYTHON_CLIENT_PREALLOCATE=false
i=0
for j in $INDIR/*.json; do
  b=$(basename $j .json); lb=${b,,}
  [ -f out/$lb/${lb}_summary_confidences.json ] && continue
  g=$((i % NG))
  # PRIVATE per-process compile cache dir -> no cross-process lock contention
  CUDA_VISIBLE_DEVICES=$g JAX_COMPILATION_CACHE_DIR=/dev/shm/af3/jax_$i $PY /app/alphafold/run_alphafold.py \
    --json_path=$j --model_dir=/dev/shm/af3/models --output_dir=/dev/shm/af3/out \
    --norun_data_pipeline > foldlog/$b.log 2>&1 &
  i=$((i+1))
  # throttle to P concurrent
  while [ $(jobs -rp | wc -l) -ge $P ]; do wait -n; done
  # stagger only during initial fill so compiles don't all collide at once
  [ $i -le $P ] && sleep 3
done
wait
echo "BATCH2_DONE launched=$i banked=$(ls out|wc -l)"
