#!/bin/bash
pkill -f run_alphafold 2>/dev/null
sleep 3
cd /dev/shm/af3
for d in out/*/; do
  bb=$(basename "$d")
  [ -f "$d/${bb}_summary_confidences.json" ] || rm -rf "$d"
done
# launch batch fully detached from this ssh session
setsid nohup bash /dev/shm/af3/batch.sh /dev/shm/af3/screen_in 21 > /dev/shm/af3/batch.log 2>&1 < /dev/null &
echo "GO_STARTED batch pid $! kept=$(ls out 2>/dev/null | wc -l)"
