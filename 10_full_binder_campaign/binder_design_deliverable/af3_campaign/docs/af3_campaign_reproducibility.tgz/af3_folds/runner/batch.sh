#!/bin/bash
# Args: $1=indir  $2=parallel_width (default 21)
INDIR=$1
P=${2:-21}
cd /dev/shm/af3
mkdir -p out foldlog jax
NG=$(nvidia-smi -L | wc -l)
PY=/alphafold3_venv/bin/python
export XLA_PYTHON_CLIENT_PREALLOCATE=false
i=0
for j in $INDIR/*.json; do
  b=$(basename $j .json)
  lb=${b,,}
  [ -f out/$lb/${lb}_summary_confidences.json ] && continue
  g=$((i % NG))
  CUDA_VISIBLE_DEVICES=$g $PY /app/alphafold/run_alphafold.py \
    --json_path=$j --model_dir=/dev/shm/af3/models --output_dir=/dev/shm/af3/out \
    --norun_data_pipeline --jax_compilation_cache_dir=/dev/shm/af3/jax \
    > foldlog/$b.log 2>&1 &
  i=$((i+1))
  while [ $(jobs -rp | wc -l) -ge $P ]; do wait -n; done
done
wait
echo "BATCH_DONE launched=$i banked=$(ls out | wc -l)"
