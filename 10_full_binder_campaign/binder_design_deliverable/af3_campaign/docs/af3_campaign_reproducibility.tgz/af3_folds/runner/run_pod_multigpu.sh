#!/bin/bash
# Args: $1=indir(json) $2=per_gpu_concurrency
set -u
INDIR=$1; M=${2:-4}
cd /workspace
mkdir -p out foldlog jax_cache
NG=$(nvidia-smi -L | wc -l)
export XLA_PYTHON_CLIENT_PREALLOCATE=false
PY=/alphafold3_venv/bin/python
fold_one(){
  local j=$1 g=$2
  local b=$(basename $j .json)
  [ -f out/${b,,}/${b,,}_summary_confidences.json ] && return
  CUDA_VISIBLE_DEVICES=$g $PY /app/alphafold/run_alphafold.py \
    --json_path=$j --model_dir=/workspace/models --output_dir=/workspace/out \
    --norun_data_pipeline --jax_compilation_cache_dir=/workspace/jax_cache \
    > foldlog/$b.log 2>&1
}
export -f fold_one; export PY
i=0
for j in $INDIR/*.json; do
  g=$((i % NG))
  # throttle: keep <= M jobs per GPU
  while [ $(jobs -rp | wc -l) -ge $((M*NG)) ]; do wait -n; done
  fold_one $j $g &
  i=$((i+1))
done
wait
echo "MULTIGPU_DONE folds_in=$i out=$(ls out | wc -l)"
