#!/bin/bash
pkill -f run_alphafold 2>/dev/null; sleep 3
setsid nohup bash /dev/shm/af3/tenseed_add.sh > /dev/shm/af3/tenadd_run.log 2>&1 < /dev/null &
echo "GO_TENADD_STARTED pid $!"
