#!/bin/bash
cd /dev/shm/af3
rm -rf refold_in refold_out; mkdir -p refold_in refold_out foldlog
# copy + patch seeds
while read f; do
  [ -z "$f" ] && continue
  python3 -c "
import json,sys
d=json.load(open('screen_in/$f'))
d['modelSeeds']=[1,2,3]
json.dump(d,open('refold_in/$f','w'))
"
done < refold_list.txt
n=$(ls refold_in/*.json 2>/dev/null | wc -l)
echo "refold_in prepared: $n JSONs with modelSeeds=[1,2,3]"
# run: batch2-style, private caches, conc 14
NG=$(nvidia-smi -L | wc -l); PY=/alphafold3_venv/bin/python
export XLA_PYTHON_CLIENT_PREALLOCATE=false
i=0
for j in refold_in/*.json; do
  b=$(basename $j .json); lb=${b,,}
  g=$((i % NG))
  CUDA_VISIBLE_DEVICES=$g JAX_COMPILATION_CACHE_DIR=/dev/shm/af3/rjax_$i $PY /app/alphafold/run_alphafold.py \
    --json_path=$j --model_dir=/dev/shm/af3/models --output_dir=/dev/shm/af3/refold_out \
    --norun_data_pipeline > foldlog/refold_$b.log 2>&1 &
  i=$((i+1))
  while [ $(jobs -rp | wc -l) -ge 14 ]; do wait -n; done
  [ $i -le 14 ] && sleep 3
done
wait
echo "REFOLD_DONE launched=$i banked=$(ls refold_out|wc -l)"
