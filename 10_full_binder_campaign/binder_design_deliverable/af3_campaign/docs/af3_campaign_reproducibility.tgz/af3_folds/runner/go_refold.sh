#!/bin/bash
pkill -f run_alphafold 2>/dev/null; sleep 3
setsid nohup bash /dev/shm/af3/refold.sh > /dev/shm/af3/refold_run.log 2>&1 < /dev/null &
echo "GO_REFOLD_STARTED pid $!"
