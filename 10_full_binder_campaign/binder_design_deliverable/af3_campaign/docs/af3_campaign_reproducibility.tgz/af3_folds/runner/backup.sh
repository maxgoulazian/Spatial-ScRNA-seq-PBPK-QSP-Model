#!/bin/bash
mkdir -p /workspace/out_backup
while true; do
  rsync -a --include="*/" --include="*_summary_confidences.json" --include="*_model.cif" --include="*confidences.json" --include="ranking_scores.csv" --exclude="*" /dev/shm/af3/out/ /workspace/out_backup/ 2>/dev/null
  sleep 300
done
