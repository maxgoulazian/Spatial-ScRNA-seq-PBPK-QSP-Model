#!/bin/bash
pkill -f run_alphafold 2>/dev/null; pkill -f batch.sh 2>/dev/null; pkill -f batch2.sh 2>/dev/null
sleep 4
cd /dev/shm/af3
rm -rf jax jax_* 2>/dev/null
for d in out/*/; do bb=$(basename "$d"); [ -f "$d/${bb}_summary_confidences.json" ] || rm -rf "$d"; done
setsid nohup bash /dev/shm/af3/batch2.sh /dev/shm/af3/screen_in 14 > /dev/shm/af3/batch2.log 2>&1 < /dev/null &
echo "GO2_STARTED pid $! kept=$(ls out 2>/dev/null|wc -l)"
