import json, glob, os, csv, sys
import numpy as np
from collections import Counter

# binder chains (first N) vs target chain (last) per target
LAYOUT = {  # target: (binder_chain_ids, target_chain_id)
  '41bb': (['A'],'B'), 'cd27': (['A'],'B'),
  'cd3': (['A','B'],'C'), 'cea5': (['A','B'],'C'),
}

def chain_index(summary_ptm_len, cids, tgt_bchains, tgt_tchain):
    # chain order in summary arrays = sorted unique chain ids (A,B,C...)
    order = sorted(set(cids))
    return order

def score_one(d, tgt):
    b = os.path.basename(d)
    sfile = f'{d}/{b}_summary_confidences.json'
    cfile = f'{d}/{b}_confidences.json'
    if not (os.path.exists(sfile) and os.path.exists(cfile)): return None
    s = json.load(open(sfile))
    bchains, tchain = LAYOUT[tgt]
    order = sorted(set(json.load(open(cfile))['token_chain_ids'])) if False else None
    # chain order in AF3 summary arrays follows the JSON chain order = A,B,C...
    order = ['A','B','C'][:len(s['chain_ptm'])]
    ti = order.index(tchain)
    bis = [order.index(x) for x in bchains]
    # binder<->target chain-pair iptm (max over binder chains) and pae-min (min)
    cpi = np.array(s['chain_pair_iptm'])
    cpp = np.array(s['chain_pair_pae_min'])
    bt_iptm = max(cpi[bi][ti] for bi in bis)
    bt_pae  = min(cpp[bi][ti] for bi in bis)
    row = dict(design=b, target=tgt,
               iptm=s['iptm'], ptm=s['ptm'], ranking_score=s['ranking_score'],
               bt_chain_iptm=round(float(bt_iptm),4),
               bt_pae_min=round(float(bt_pae),4),
               has_clash=s.get('has_clash',0), frac_disorder=s.get('fraction_disordered',0))
    return row

rows=[]
for tgt in LAYOUT:
    ds = [os.path.dirname(x) for x in glob.glob(f'pod*/{tgt}_r*/{tgt}_r*_summary_confidences.json') if 'seed-' not in x]
    for d in ds:
        r = score_one(d, tgt)
        if r: rows.append(r)
    print(f'{tgt}: scored {sum(1 for r in rows if r["target"]==tgt)}', file=sys.stderr)

# write master
cols=['design','target','iptm','ptm','ranking_score','bt_chain_iptm','bt_pae_min','has_clash','frac_disorder']
with open('af3_screen_scores.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(rows)
print(f'TOTAL rows: {len(rows)}', file=sys.stderr)
