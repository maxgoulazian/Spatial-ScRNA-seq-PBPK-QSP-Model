import glob, os, csv
# ipSAE labels binder chains H (and L for VH/VL) and target T. Interface = H-T and/or L-T.
def parse(txt):
    best={}  # binder_chain -> metrics, from the 'max' rows involving T
    for line in open(txt):
        p=line.split()
        if len(p)<13 or p[4]!='max': continue
        c1,c2=p[0],p[1]
        pair={c1,c2}
        if 'T' in pair and len(pair)==2:
            bchain=list(pair-{'T'})[0]
            if bchain in ('H','L'):
                try:
                    best[bchain]=dict(ipsae=float(p[5]), iptm=float(p[8]),
                                      pdockq=float(p[10]), pdockq2=float(p[11]), lis=float(p[13-1]))
                except: pass
    if not best: return None
    # binder-target interface: for VH/VL take the chain with MAX ipsae (dominant contact),
    # but also keep sum of contacts. For VHH only H exists.
    bc=max(best,key=lambda k:best[k]['ipsae'])
    r=dict(best[bc]); r['contact_chain']=bc
    r['ipsae_H']=best.get('H',{}).get('ipsae')
    r['ipsae_L']=best.get('L',{}).get('ipsae')
    return r

rows=[]
for tgt in ['41bb','cd27','cd3','cea5']:
    for txt in glob.glob(f"pod*/{tgt}_r*/{tgt}_r*_model_10_15.txt"):
        design=os.path.basename(txt).replace("_model_10_15.txt","")
        r=parse(txt)
        if r:
            r['design']=design; r['target']=tgt
            rows.append(r)
cols=['design','target','ipsae','pdockq','pdockq2','lis','contact_chain','ipsae_H','ipsae_L']
with open("ipsae_scores.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
    for r in rows: w.writerow({k:r.get(k) for k in cols})
print(f"parsed {len(rows)} ipSAE interface scores")
# quick top-5 per target by ipsae
import collections
byt=collections.defaultdict(list)
for r in rows: byt[r['target']].append(r)
for t in ['41bb','cd27','cd3','cea5']:
    top=sorted(byt[t],key=lambda r:-r['ipsae'])[:3]
    print(f"\n{t} top-3 ipSAE:")
    for r in top: print(f"  {r['design']}: ipSAE={r['ipsae']:.3f} pDockQ={r['pdockq']:.3f} LIS={r['lis']:.3f}")
