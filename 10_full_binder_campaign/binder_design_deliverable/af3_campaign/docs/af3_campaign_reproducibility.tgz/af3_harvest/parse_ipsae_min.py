import glob, os, csv
# CONSERVATIVE: ipSAE = MIN of the two asymmetric directions per chain pair (lit-review protocol).
# Binder chains labeled H (+L for VH/VL), target T. Interface pairs = {H,T} and {L,T}.
def parse(txt):
    # collect asym rows: (c1,c2)->ipsae  ; also pdockq/lis come per-pair (symmetric-ish, take min too for ipsae-driven)
    asym={}  # frozenset pair -> list of (ipsae,pdockq,pdockq2,lis)
    for line in open(txt):
        p=line.split()
        if len(p)<14 or p[4]!='asym': continue
        c1,c2=p[0],p[1]
        pair=frozenset([c1,c2])
        if 'T' in pair and len(pair)==2 and (list(pair-{'T'})[0] in ('H','L')):
            try:
                asym.setdefault(pair,[]).append(dict(ipsae=float(p[5]),pdockq=float(p[10]),pdockq2=float(p[11]),lis=float(p[12])))
            except: pass
    if not asym: return None
    # per pair: MIN ipsae across the two directions (conservative). pdockq is symmetric; lis take min.
    perpair={}
    for pair,rows in asym.items():
        bchain=list(pair-{'T'})[0]
        mn=min(rows,key=lambda r:r['ipsae'])  # the direction giving the lower (conservative) ipsae
        perpair[bchain]=dict(ipsae=mn['ipsae'],
                             pdockq=min(r['pdockq'] for r in rows),
                             pdockq2=min(r['pdockq2'] for r in rows),
                             lis=min(r['lis'] for r in rows))
    # aggregate across binder chains: dominant contacting chain = max ipsae among the conservative per-pair values
    bc=max(perpair,key=lambda k:perpair[k]['ipsae'])
    r=dict(perpair[bc]); r['contact_chain']=bc
    r['ipsae_H']=perpair.get('H',{}).get('ipsae')
    r['ipsae_L']=perpair.get('L',{}).get('ipsae')
    return r

rows=[]
for tgt in ['41bb','cd27','cd3','cea5']:
    for txt in glob.glob(f"pod*/{tgt}_r*/{tgt}_r*_model_10_15.txt"):
        design=os.path.basename(txt).replace("_model_10_15.txt","")
        r=parse(txt)
        if r:
            r['design']=design; r['target']=tgt; rows.append(r)
cols=['design','target','ipsae','pdockq','pdockq2','lis','contact_chain','ipsae_H','ipsae_L']
with open("ipsae_scores.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
    for r in rows: w.writerow({k:r.get(k) for k in cols})
print(f"parsed {len(rows)} ipSAE interface scores (MIN-of-directions)")
import collections
byt=collections.defaultdict(list)
for r in rows: byt[r['target']].append(r)
for t in ['41bb','cd27','cd3','cea5']:
    top=sorted(byt[t],key=lambda r:-r['ipsae'])[:3]
    n5=sum(1 for r in byt[t] if r['ipsae']>0.5)
    print(f"{t}: ipSAE>0.5={n5}  top3=" + ", ".join(f"{r['design'].split('_')[1]}:{r['ipsae']:.3f}" for r in top))
