# AF3 De Novo Binder Screen — Results Record

_Generated 2026-07-13 08:12. Tier-1 (1-seed) screen, scored by AF3 confidence + ipSAE interface metrics._

> **Correction (v2):** ipSAE aggregation changed from MAX-of-directions to **MIN-of-directions** (the conservative lit-review protocol). MAX was an optimistic error; MIN penalizes interfaces that are confident in only one direction. This lowered ipSAE>0.5 counts from 2/2/1/6 to 0/1/0/1 but did **not** change the top-ranked design per target. A LIS column-index bug (read n0res instead of LIS) was also fixed in the same pass.

## Screen scope
- **3,964 / 3,974 designs folded** (99.7%) on 3× RunPod A100 pods (21 GPUs), 1 seed / 5 diffusion samples each, ~$60 GPU, ~2.8h
- AF3 iPTM/pTM/chain-pair-iPTM/chain-pair-PAE-min on all 3,964; ipSAE/pDockQ/pDockQ2/LIS on the 256-design gated shortlist (top 80/target)
- **ipSAE = MIN of the two asymmetric directions** (Dunbrack ipsae.py, cutoff 10/15), binder↔target chain pairs only (H↔T, L↔T)

## Per-target hit summary (MIN-based ipSAE)

| Target | Format | Folds | Top iPTM | Top ipSAE(min) | ipSAE>0.5 | ipSAE>0.4 |
|---|---|---|---|---|---|---|
| 4-1BB (TNFRSF9) | VHH | 981 | 0.81 | 0.460 | 0 | 1 |
| CD27 (TNFRSF7) | VHH | 986 | 0.83 | 0.529 | 1 | 1 |
| CD3ε | VH/VL | 997 | 0.80 | 0.491 | 0 | 1 |
| CEA5 (CEACAM5) | VH/VL | 1000 | 0.90 | 0.642 | 1 | 17 |

## Top-5 finalists per target (ipSAE-min-led composite)

### 4-1BB (TNFRSF9) (VHH)
| design | ipSAE(min) | iPTM | pTM | binder↔tgt PAE(Å) | pDockQ | LIS | composite |
|---|---|---|---|---|---|---|---|
| 41bb_r0867_41bb_62 | 0.460 | 0.81 | 0.75 | 1.76 | 0.384 | 0.452 | 0.610 |
| 41bb_r0025_41bb_14 | 0.318 | 0.79 | 0.68 | 1.99 | 0.354 | 0.405 | 0.527 |
| 41bb_r0658_41bb_59 | 0.383 | 0.66 | 0.69 | 2.07 | 0.324 | 0.341 | 0.520 |
| 41bb_r0750_41bb_3 | 0.223 | 0.70 | 0.66 | 2.81 | 0.300 | 0.294 | 0.438 |
| 41bb_r0492_41bb_3 | 0.206 | 0.72 | 0.65 | 2.88 | 0.297 | 0.310 | 0.435 |

### CD27 (TNFRSF7) (VHH)
| design | ipSAE(min) | iPTM | pTM | binder↔tgt PAE(Å) | pDockQ | LIS | composite |
|---|---|---|---|---|---|---|---|
| cd27_r0011_cd27_24 | 0.529 | 0.83 | 0.84 | 1.18 | 0.334 | 0.528 | 0.663 |
| cd27_r0143_cd27_35 | 0.397 | 0.75 | 0.75 | 1.51 | 0.240 | 0.392 | 0.560 |
| cd27_r0846_cd27_13 | 0.391 | 0.74 | 0.81 | 2.04 | 0.377 | 0.398 | 0.550 |
| cd27_r0018_cd27_75 | 0.341 | 0.73 | 0.75 | 2.07 | 0.295 | 0.335 | 0.516 |
| cd27_r0105_cd27_75 | 0.315 | 0.70 | 0.74 | 2.20 | 0.264 | 0.313 | 0.492 |

### CD3ε (VH/VL)
| design | ipSAE(min) | iPTM | pTM | binder↔tgt PAE(Å) | pDockQ | LIS | composite |
|---|---|---|---|---|---|---|---|
| cd3_r0478_cd3_65 | 0.491 | 0.80 | 0.78 | 2.02 | 0.180 | 0.483 | 0.624 |
| cd3_r0303_cd3_73 | 0.327 | 0.78 | 0.78 | 2.49 | 0.266 | 0.401 | 0.524 |
| cd3_r0866_cd3_65 | 0.344 | 0.70 | 0.74 | 3.12 | 0.104 | 0.339 | 0.500 |
| cd3_r0925_cd3_65 | 0.341 | 0.71 | 0.76 | 3.01 | 0.125 | 0.318 | 0.500 |
| cd3_r0618_cd3_30 | 0.319 | 0.72 | 0.74 | 2.73 | 0.227 | 0.342 | 0.497 |

### CEA5 (CEACAM5) (VH/VL)
| design | ipSAE(min) | iPTM | pTM | binder↔tgt PAE(Å) | pDockQ | LIS | composite |
|---|---|---|---|---|---|---|---|
| cea5_r0420_cea5_52 | 0.642 | 0.90 | 0.92 | 1.18 | 0.200 | 0.601 | 0.744 |
| cea5_r0160_cea5_93 | 0.484 | 0.88 | 0.91 | 1.83 | 0.268 | 0.505 | 0.644 |
| cea5_r0543_cea5_67 | 0.494 | 0.86 | 0.90 | 1.97 | 0.297 | 0.496 | 0.642 |
| cea5_r0473_cea5_65 | 0.487 | 0.86 | 0.90 | 2.00 | 0.252 | 0.507 | 0.639 |
| cea5_r0852_cea5_12 | 0.474 | 0.87 | 0.90 | 1.84 | 0.247 | 0.495 | 0.635 |

## Interpretation (corrected)
- **Rankings stable, confidence honestly lower.** MIN aggregation confirms the same top design per target (4-1BB r0867, CD27 r0011, CD3 r0478, CEA5 r0420) but reports lower ipSAE, so the 'confident interface' bar (>0.5) is now cleared by only CD27 and CEA5 top hits.
- **CEA5** remains strongest (top ipSAE-min 0.642, iPTM 0.90) — expected for a large Ig-like domain as VH/VL.
- **CD27** strongest costim VHH (ipSAE-min 0.529, PAE 1.18Å) — only costim design clearing 0.5.
- **4-1BB** hardest (top ipSAE-min 0.460, just under 0.5) but iPTM 0.81 / PAE 1.76Å — a real interface that the conservative metric marks borderline; the 3-seed refold will resolve whether it firms up.
- **CD3ε** top ipSAE-min 0.491 — also borderline; refold will clarify.
- The costim VHHs being borderline under MIN is the honest state: de novo VHH vs small cysteine-rich TNFR domains is hard, and the conservative metric refuses to over-call it. The 3-seed → 10-seed refold tier is exactly the tie-breaker for these borderline cases.

## Data locations
- `af3_master_scored.csv` — all 3,964 folds + MIN-based ipSAE + composite (THE ranked table)
- `af3_screen_scores.csv` — core AF3 metrics, all folds; `ipsae_scores.csv` — MIN-based interface scores, 256 shortlist
- Raw folds: pod tarballs (checkpointed artifacts)